# BARBER VIPROMAX — ثلاثة تطبيقات حقيقية (Flutter + Supabase)

| التطبيق | المجلد | من يستخدمه |
|---|---|---|
| BARBER VIPROMAX | `apps/customer` | الزبائن (اسم + هاتف + صورة اختيارية) |
| BARBER VIPROMAX للحلاقين | `apps/barber` | الحلاقون (تُوزّعه عليهم) |
| BARBER VIPROMAX OWNER | `apps/owner` | أنت فقط |

المكتبة المشتركة (الشعار، الألوان، الاتصال بقاعدة البيانات) في `packages/core`.
الثلاثة متصلة ببعضها عن بعد عبر قاعدة Supabase واحدة.

## الخطوة 1: قاعدة البيانات (Supabase)
1. **Authentication → Providers**: فعّل **Anonymous sign-ins**، وفي Email أوقف **Confirm email**.
2. **SQL Editor**: الصق محتوى `supabase/01_vipromax.sql` ونفّذه.
   - يضيف جداول جديدة بالبادئة `vp_` ولا يلمس جداولك القديمة (profiles, barbers, bookings…).
3. **Authentication → Users → Add user**: أنشئ حسابك (بريد + كلمة سر)، ثم نفّذ في SQL Editor:
   ```sql
   insert into vp_profiles(id, role, full_name)
   select id, 'owner', 'المالك' from auth.users where email = 'بريدك@example.com'
   on conflict (id) do update set role = 'owner';
   ```
4. **Project Settings → API**: انسخ `Project URL` و`anon public key`.

## الخطوة 2: ضع المفاتيح (مرة واحدة)
افتح `packages/core/lib/core.dart` وبدّل:
```dart
const supabaseUrl = 'PUT_YOUR_SUPABASE_URL';
const supabaseAnonKey = 'PUT_YOUR_SUPABASE_ANON_KEY';
```

## الخطوة 3: التجهيز والبناء
ثبّت Flutter ثم:
```bash
bash setup.sh
cd apps/customer && flutter build apk --release   # ملف APK للزبائن
cd ../barber     && flutter build apk --release   # للحلاقين
cd ../owner      && flutter build apk --release   # للمالك
```
الملف الناتج: `build/app/outputs/flutter-apk/app-release.apk` داخل كل تطبيق.
للآيفون تحتاج جهاز Mac وحساب Apple Developer: `flutter build ipa`.

## كيف يعمل النظام
- **الزبون** يرى الحلاقين المعتمدين فقط، ويختار اليوم والساعة بحرية، فيصل الطلب للحلاق فورًا.
- عند **قبول الحلاق** تظهر للزبون نافذة: صورة المحل، صورة الحلاق في دائرة، الاسم، الهاتف (اتصال بنقرة)، العنوان. رقم الحلاق لا يُكشف للزبون قبل القبول.
- **الحلاق** يسجّل (اسم المحل والحلاق والهاتف والعنوان والصور) ثم ينتظر **موافقة المالك**.
- **المالك** يوافق على الحلاقين، ويرى الزبائن بأسمائهم وأرقامهم، وكل الطلبات، ويصله إشعار عند كل اتفاق بين زبون وحلاق.
- **المال:** كل خدمة مكتملة = 1500 دج → 500 للمنصة + 1000 للحلاق، عملية واحدة فقط (قيد UNIQUE في القاعدة)، والسجلات المالية لا تُعدَّل ولا تُحذف، والزبون لا يصل إليها إطلاقًا.

## ما ينقص (يُضاف لاحقًا)
- **إشعارات الهاتف الخارجية (Push)** عندما يكون التطبيق مغلقًا: تحتاج Firebase Cloud Messaging. حاليًا الإشعارات فورية داخل التطبيق وهو مفتوح، وكلها محفوظة في جدول `vp_notifications` جاهزة للربط.
- **تسجيل الزبون بالاسم والهاتف** يعتمد دخولًا مجهولًا مرتبطًا بالجهاز؛ إن حذف الزبون التطبيق فقد حسابه. للتوثيق الحقيقي برمز SMS تلزم خدمة رسائل.
- **أيقونة التطبيق** الحالية افتراضية من Flutter؛ أصنع لك أيقونة من الشعار عند الطلب.
