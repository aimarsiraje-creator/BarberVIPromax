-- ============================================================
-- BARBER VIPROMAX - ترحيل آمن (إضافات فقط، لا حذف ولا تعديل لجداولك القديمة)
-- جداول جديدة بالبادئة vp_ حتى لا تتعارض مع الجداول الموجودة
-- شغّله مرة واحدة في Supabase > SQL Editor
-- ============================================================
create extension if not exists pgcrypto;

-- ---------- الجداول ----------
create table if not exists vp_profiles(
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'customer' check (role in ('customer','barber','owner')),
  full_name text not null default '',
  phone text not null default '',
  avatar_url text,
  created_at timestamptz not null default now());

create table if not exists vp_barbers(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  barber_name text not null,
  shop_name text not null,
  phone text not null,
  address text not null,
  barber_photo_url text,
  shop_photo_url text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','blocked')),
  is_available boolean not null default true,
  rating numeric(2,1) not null default 5.0,
  created_at timestamptz not null default now());

create table if not exists vp_bookings(
  id uuid primary key default gen_random_uuid(),
  barber_id uuid not null references vp_barbers(id),
  customer_id uuid references auth.users(id),
  customer_name text not null,
  customer_phone text not null default '',
  customer_photo_url text,
  barber_name text not null,
  shop_name text not null,
  barber_phone text not null default '',
  barber_photo_url text,
  scheduled_at timestamptz not null,
  source text not null default 'app' check (source in ('app','walkin')),
  status text not null default 'pending' check (status in ('pending','accepted','rejected','cancelled','completed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now());
create unique index if not exists vp_bookings_slot on vp_bookings(barber_id, scheduled_at) where status in ('pending','accepted');

-- عملية مالية واحدة فقط لكل خدمة (UNIQUE على booking_id)
create table if not exists vp_completions(
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references vp_bookings(id),
  barber_id uuid not null references vp_barbers(id),
  gross int not null check (gross = platform_fee + barber_net),
  platform_fee int not null,
  barber_net int not null,
  completed_at timestamptz not null default now(),
  created_by uuid not null);

create table if not exists vp_settlements(
  id uuid primary key default gen_random_uuid(),
  barber_id uuid not null references vp_barbers(id),
  amount int not null check (amount > 0),
  note text not null default '',
  created_by uuid not null,
  created_at timestamptz not null default now());

create table if not exists vp_notifications(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  body text not null default '',
  booking_id uuid,
  is_read boolean not null default false,
  created_at timestamptz not null default now());

-- ---------- دوال مساعدة ----------
create or replace function vp_is_owner() returns boolean language sql stable security definer set search_path=public as
$$ select exists(select 1 from vp_profiles where id = auth.uid() and role = 'owner'); $$;

create or replace function vp_my_barber() returns uuid language sql stable security definer set search_path=public as
$$ select id from vp_barbers where user_id = auth.uid() limit 1; $$;

create or replace function vp_notify(p_user uuid, p_title text, p_body text, p_booking uuid) returns void
language sql security definer set search_path=public as
$$ insert into vp_notifications(user_id,title,body,booking_id) values (p_user,p_title,p_body,p_booking); $$;

create or replace function vp_notify_owners(p_title text, p_body text, p_booking uuid) returns void
language sql security definer set search_path=public as
$$ insert into vp_notifications(user_id,title,body,booking_id) select id,p_title,p_body,p_booking from vp_profiles where role='owner'; $$;

revoke all on function vp_notify(uuid,text,text,uuid) from public, anon, authenticated;
revoke all on function vp_notify_owners(text,text,uuid) from public, anon, authenticated;

-- ---------- حراس: لا تغيير للدور/الحالة إلا من المالك ----------
create or replace function vp_guard_profile() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is not null and new.role <> old.role and not vp_is_owner() then
    raise exception 'role change not allowed';
  end if;
  return new;
end $$;
drop trigger if exists vp_guard_profile_t on vp_profiles;
create trigger vp_guard_profile_t before update on vp_profiles for each row execute function vp_guard_profile();

create or replace function vp_guard_barber() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is not null and not vp_is_owner() then
    if new.user_id <> old.user_id or new.status <> old.status or new.rating <> old.rating then
      raise exception 'not allowed';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists vp_guard_barber_t on vp_barbers;
create trigger vp_guard_barber_t before update on vp_barbers for each row execute function vp_guard_barber();

-- السجلات المالية لا تُعدَّل ولا تُحذف أبدًا
create or replace function vp_immutable() returns trigger language plpgsql as $$
begin raise exception 'financial records are immutable'; end $$;
drop trigger if exists vp_immut_c on vp_completions;
create trigger vp_immut_c before update or delete on vp_completions for each row execute function vp_immutable();
drop trigger if exists vp_immut_s on vp_settlements;
create trigger vp_immut_s before update or delete on vp_settlements for each row execute function vp_immutable();

-- ---------- RLS ----------
alter table vp_profiles enable row level security;
alter table vp_barbers enable row level security;
alter table vp_bookings enable row level security;
alter table vp_completions enable row level security;
alter table vp_settlements enable row level security;
alter table vp_notifications enable row level security;

drop policy if exists p_prof_sel on vp_profiles;
create policy p_prof_sel on vp_profiles for select to authenticated using (id = auth.uid() or vp_is_owner());
drop policy if exists p_prof_upd on vp_profiles;
create policy p_prof_upd on vp_profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists p_barb_sel on vp_barbers;
create policy p_barb_sel on vp_barbers for select to authenticated using (user_id = auth.uid() or vp_is_owner());
drop policy if exists p_barb_upd on vp_barbers;
create policy p_barb_upd on vp_barbers for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists p_book_sel on vp_bookings;
create policy p_book_sel on vp_bookings for select to authenticated
  using (customer_id = auth.uid() or barber_id = vp_my_barber() or vp_is_owner());

drop policy if exists p_comp_sel on vp_completions;
create policy p_comp_sel on vp_completions for select to authenticated using (barber_id = vp_my_barber() or vp_is_owner());

drop policy if exists p_sett_sel on vp_settlements;
create policy p_sett_sel on vp_settlements for select to authenticated using (barber_id = vp_my_barber() or vp_is_owner());

drop policy if exists p_note_sel on vp_notifications;
create policy p_note_sel on vp_notifications for select to authenticated using (user_id = auth.uid());
drop policy if exists p_note_upd on vp_notifications;
create policy p_note_upd on vp_notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

revoke all on vp_profiles, vp_barbers, vp_bookings, vp_completions, vp_settlements, vp_notifications from anon;

-- ---------- عرض الحلاقين للزبائن (بدون رقم الهاتف) ----------
create or replace view vp_barbers_public as
  select id, barber_name, shop_name, address, barber_photo_url, shop_photo_url, rating, is_available
  from vp_barbers where status = 'approved' and is_available;
revoke all on vp_barbers_public from anon;
grant select on vp_barbers_public to authenticated;

-- ---------- الحسابات: الحلاق يرى صفه فقط، والمالك يرى الكل ----------
create or replace view vp_finance with (security_invoker = true) as
select b.id as barber_id, b.barber_name, b.shop_name,
  coalesce(c.n,0) as services, coalesce(c.gross,0) as gross,
  coalesce(c.fee,0) as platform_total, coalesce(c.net,0) as barber_total,
  coalesce(s.paid,0) as paid_to_owner,
  coalesce(c.fee,0) - coalesce(s.paid,0) as remaining
from vp_barbers b
left join (select barber_id, count(*) n, sum(gross) gross, sum(platform_fee) fee, sum(barber_net) net
           from vp_completions group by barber_id) c on c.barber_id = b.id
left join (select barber_id, sum(amount) paid from vp_settlements group by barber_id) s on s.barber_id = b.id;
revoke all on vp_finance from anon;
grant select on vp_finance to authenticated;

-- ---------- الدوال المسموح بها للتطبيقات ----------
create or replace function vp_ensure_profile(p_role text, p_name text, p_phone text, p_avatar text default null)
returns void language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  if p_role not in ('customer','barber') then raise exception 'invalid role'; end if;
  insert into vp_profiles(id, role, full_name, phone, avatar_url)
  values (auth.uid(), p_role, p_name, p_phone, p_avatar)
  on conflict (id) do update set full_name = excluded.full_name, phone = excluded.phone,
    avatar_url = coalesce(excluded.avatar_url, vp_profiles.avatar_url);
end $$;

create or replace function vp_register_barber(p_name text, p_shop text, p_phone text, p_address text, p_bphoto text, p_sphoto text)
returns uuid language plpgsql security definer set search_path=public as $$
declare v uuid;
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  perform vp_ensure_profile('barber', p_name, p_phone, p_bphoto);
  insert into vp_barbers(user_id, barber_name, shop_name, phone, address, barber_photo_url, shop_photo_url)
  values (auth.uid(), p_name, p_shop, p_phone, p_address, p_bphoto, p_sphoto)
  on conflict (user_id) do update set barber_name = excluded.barber_name, shop_name = excluded.shop_name,
    phone = excluded.phone, address = excluded.address,
    barber_photo_url = coalesce(excluded.barber_photo_url, vp_barbers.barber_photo_url),
    shop_photo_url = coalesce(excluded.shop_photo_url, vp_barbers.shop_photo_url)
  returning id into v;
  perform vp_notify_owners('طلب انضمام حلاق جديد', p_name || ' - ' || p_shop, null);
  return v;
end $$;

create or replace function vp_set_barber_status(p_barber uuid, p_status text) returns void
language plpgsql security definer set search_path=public as $$
declare b vp_barbers;
begin
  if not vp_is_owner() then raise exception 'owner only'; end if;
  if p_status not in ('approved','rejected','blocked') then raise exception 'invalid status'; end if;
  update vp_barbers set status = p_status where id = p_barber returning * into b;
  if b.id is not null then
    perform vp_notify(b.user_id,
      case p_status when 'approved' then 'تمت الموافقة على انضمامك' when 'rejected' then 'تم رفض طلب انضمامك' else 'تم إيقاف حسابك' end, '', null);
  end if;
end $$;

create or replace function vp_create_booking(p_barber uuid, p_at timestamptz) returns uuid
language plpgsql security definer set search_path=public as $$
declare b vp_barbers; p vp_profiles; v uuid;
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  select * into p from vp_profiles where id = auth.uid();
  if not found then raise exception 'complete your profile first'; end if;
  select * into b from vp_barbers where id = p_barber and status = 'approved' and is_available;
  if not found then raise exception 'barber not available'; end if;
  if p_at < now() then raise exception 'time is in the past'; end if;
  insert into vp_bookings(barber_id, customer_id, customer_name, customer_phone, customer_photo_url,
                          barber_name, shop_name, barber_phone, barber_photo_url, scheduled_at)
  values (b.id, auth.uid(), p.full_name, p.phone, p.avatar_url, b.barber_name, b.shop_name, b.phone, b.barber_photo_url, p_at)
  returning id into v;
  perform vp_notify(b.user_id, 'طلب حجز جديد', p.full_name || ' يريد موعدًا', v);
  return v;
end $$;

create or replace function vp_respond_booking(p_booking uuid, p_accept boolean) returns void
language plpgsql security definer set search_path=public as $$
declare bk vp_bookings;
begin
  select * into bk from vp_bookings where id = p_booking and barber_id = vp_my_barber() for update;
  if not found then raise exception 'booking not found'; end if;
  if bk.status <> 'pending' then raise exception 'booking already handled'; end if;
  update vp_bookings set status = case when p_accept then 'accepted' else 'rejected' end, updated_at = now() where id = p_booking;
  if bk.customer_id is not null then
    perform vp_notify(bk.customer_id, case when p_accept then 'تم قبول حجزك' else 'تم رفض حجزك' end,
                      bk.barber_name || ' - ' || bk.shop_name, p_booking);
  end if;
  if p_accept then
    perform vp_notify_owners('اتفاق جديد', bk.customer_name || ' اتفق مع ' || bk.barber_name, p_booking);
  end if;
end $$;

create or replace function vp_cancel_booking(p_booking uuid) returns void
language plpgsql security definer set search_path=public as $$
declare bk vp_bookings; bu uuid;
begin
  select * into bk from vp_bookings where id = p_booking and customer_id = auth.uid() for update;
  if not found then raise exception 'booking not found'; end if;
  if bk.status not in ('pending','accepted') then raise exception 'cannot cancel'; end if;
  update vp_bookings set status = 'cancelled', updated_at = now() where id = p_booking;
  select user_id into bu from vp_barbers where id = bk.barber_id;
  perform vp_notify(bu, 'تم إلغاء حجز', bk.customer_name, p_booking);
end $$;

-- إتمام الخدمة: عملية مالية واحدة فقط (1500 = 500 للمنصة + 1000 للحلاق)
create or replace function vp_complete_booking(p_booking uuid) returns void
language plpgsql security definer set search_path=public as $$
declare bk vp_bookings;
begin
  select * into bk from vp_bookings where id = p_booking and barber_id = vp_my_barber() for update;
  if not found then raise exception 'booking not found'; end if;
  if bk.status <> 'accepted' then raise exception 'booking must be accepted first'; end if;
  insert into vp_completions(booking_id, barber_id, gross, platform_fee, barber_net, created_by)
  values (p_booking, bk.barber_id, 1500, 500, 1000, auth.uid());
  update vp_bookings set status = 'completed', updated_at = now() where id = p_booking;
end $$;

create or replace function vp_create_walkin(p_name text) returns uuid
language plpgsql security definer set search_path=public as $$
declare b vp_barbers; v uuid;
begin
  select * into b from vp_barbers where user_id = auth.uid() and status = 'approved';
  if not found then raise exception 'barber only'; end if;
  insert into vp_bookings(barber_id, customer_name, barber_name, shop_name, barber_phone, barber_photo_url, scheduled_at, source, status)
  values (b.id, coalesce(nullif(trim(p_name),''),'زبون مباشر'), b.barber_name, b.shop_name, b.phone, b.barber_photo_url, now(), 'walkin', 'accepted')
  returning id into v;
  return v;
end $$;

-- بيانات الحلاق تظهر للزبون فقط بعد قبول حجزه
create or replace function vp_booking_contact(p_booking uuid) returns jsonb
language plpgsql security definer set search_path=public as $$
declare r jsonb;
begin
  select jsonb_build_object('barber_name', b.barber_name, 'shop_name', b.shop_name, 'phone', b.phone,
         'address', b.address, 'barber_photo_url', b.barber_photo_url, 'shop_photo_url', b.shop_photo_url)
  into r from vp_bookings k join vp_barbers b on b.id = k.barber_id
  where k.id = p_booking and k.customer_id = auth.uid() and k.status in ('accepted','completed');
  if r is null then raise exception 'not available'; end if;
  return r;
end $$;

create or replace function vp_record_settlement(p_barber uuid, p_amount int, p_note text default '') returns void
language plpgsql security definer set search_path=public as $$
begin
  if not vp_is_owner() then raise exception 'owner only'; end if;
  insert into vp_settlements(barber_id, amount, note, created_by) values (p_barber, p_amount, coalesce(p_note,''), auth.uid());
end $$;

revoke all on function vp_ensure_profile(text,text,text,text), vp_register_barber(text,text,text,text,text,text),
  vp_set_barber_status(uuid,text), vp_create_booking(uuid,timestamptz), vp_respond_booking(uuid,boolean),
  vp_cancel_booking(uuid), vp_complete_booking(uuid), vp_create_walkin(text), vp_booking_contact(uuid),
  vp_record_settlement(uuid,int,text) from public, anon;
grant execute on function vp_ensure_profile(text,text,text,text), vp_register_barber(text,text,text,text,text,text),
  vp_set_barber_status(uuid,text), vp_create_booking(uuid,timestamptz), vp_respond_booking(uuid,boolean),
  vp_cancel_booking(uuid), vp_complete_booking(uuid), vp_create_walkin(text), vp_booking_contact(uuid),
  vp_record_settlement(uuid,int,text) to authenticated;

-- ---------- تخزين الصور ----------
insert into storage.buckets(id, name, public) values ('vp-photos','vp-photos', true) on conflict (id) do nothing;
drop policy if exists vp_photos_read on storage.objects;
create policy vp_photos_read on storage.objects for select using (bucket_id = 'vp-photos');
drop policy if exists vp_photos_ins on storage.objects;
create policy vp_photos_ins on storage.objects for insert to authenticated
  with check (bucket_id = 'vp-photos' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists vp_photos_upd on storage.objects;
create policy vp_photos_upd on storage.objects for update to authenticated
  using (bucket_id = 'vp-photos' and (storage.foldername(name))[1] = auth.uid()::text);

-- ---------- التحديث الفوري ----------
do $$ begin alter publication supabase_realtime add table vp_bookings; exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table vp_notifications; exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table vp_barbers; exception when duplicate_object then null; end $$;

-- ============================================================
-- إنشاء حساب المالك (بعد إضافة مستخدم من Authentication > Users):
-- insert into vp_profiles(id, role, full_name) select id, 'owner', 'المالك' from auth.users
--   where email = 'بريدك@example.com' on conflict (id) do update set role = 'owner';
-- ============================================================
