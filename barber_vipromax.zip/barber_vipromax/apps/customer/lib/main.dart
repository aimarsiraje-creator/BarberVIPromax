import 'dart:async';
import 'dart:typed_data';

import 'package:core/core.dart';
import 'package:flutter/material.dart';

void main() => bootstrap(const VpApp(title: 'BARBER VIPROMAX', home: Gate()));

// ============ بوابة الدخول ============
class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  Future<Map<String, dynamic>?> _load() async {
    final u = db.auth.currentUser;
    if (u == null) return null;
    return await db.from('vp_profiles').select().eq('id', u.id).maybeSingle();
  }

  late Future<Map<String, dynamic>?> f = _load();
  void reload() => setState(() => f = _load());

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>?>(
        future: f,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return const Scaffold(body: Center(child: Logo(size: 90)));
          }
          final me = s.data;
          if (me == null) return Login(onDone: reload);
          return Home(
            me: me,
            onLogout: () async {
              await db.auth.signOut();
              reload();
            },
          );
        },
      );
}

// ============ تسجيل الدخول: الاسم + الهاتف (+ صورة اختيارية) ============
class Login extends StatefulWidget {
  const Login({super.key, required this.onDone});
  final VoidCallback onDone;
  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final n = TextEditingController(), p = TextEditingController();
  Uint8List? photo;
  bool busy = false;

  Future<void> go() async {
    if (n.text.trim().isEmpty || p.text.replaceAll(RegExp(r'\D'), '').length < 9) {
      snack(context, 'أدخل الاسم ورقم هاتف صحيح');
      return;
    }
    setState(() => busy = true);
    try {
      if (db.auth.currentUser == null) await db.auth.signInAnonymously();
      String? url;
      if (photo != null) url = await uploadPhoto(photo!, 'me');
      await db.rpc('vp_ensure_profile',
          params: {'p_role': 'customer', 'p_name': n.text.trim(), 'p_phone': p.text.trim(), 'p_avatar': url});
      widget.onDone();
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: ListView(padding: const EdgeInsets.all(24), children: [
            const SizedBox(height: 20),
            const Center(child: Logo(size: 96)),
            const SizedBox(height: 10),
            const Center(
                child: Text('BARBER VIPROMAX',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: 3, color: C.gold2))),
            const Center(child: Text('تطبيق الزبائن', style: TextStyle(color: C.mu))),
            const SizedBox(height: 24),
            PhotoField(label: 'أضف صورتك (اختياري)', onPicked: (b) => photo = b),
            Field('الاسم', n),
            Field('رقم الهاتف', p, keyboard: TextInputType.phone),
            const SizedBox(height: 4),
            GoldButton('دخول', go, busy: busy),
          ]),
        ),
      );
}

// ============ الرئيسية ============
class Home extends StatefulWidget {
  const Home({super.key, required this.me, required this.onLogout});
  final Map<String, dynamic> me;
  final VoidCallback onLogout;
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;
  StreamSubscription? sub;
  final seen = <String, String>{};
  bool first = true;

  @override
  void initState() {
    super.initState();
    // عند قبول الحلاق للحجز تظهر شاشة بيانات الحلاق فورًا
    sub = db.from('vp_bookings').stream(primaryKey: ['id']).eq('customer_id', db.auth.currentUser!.id).listen((rows) {
      for (final r in rows) {
        final id = r['id'] as String, st = r['status'] as String;
        if (!first && seen[id] == 'pending' && st == 'accepted' && mounted) showContact(context, id);
        seen[id] = st;
      }
      first = false;
    });
  }

  @override
  void dispose() {
    sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const BrandTitle('تطبيق الزبائن'),
          actions: [IconButton(onPressed: widget.onLogout, icon: const Icon(Icons.logout, color: C.mu))],
        ),
        body: tab == 0 ? const BarberList() : const MyBookings(),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.content_cut), label: 'الحلاقون'),
            NavigationDestination(icon: Icon(Icons.confirmation_number_outlined), label: 'حجوزاتي'),
          ],
        ),
      );
}

/// نافذة بيانات الحلاق بعد القبول: صورة المحل، صورة الحلاق في دائرة، الاسم، الهاتف (اتصال)، العنوان
Future<void> showContact(BuildContext c, String bookingId) async {
  try {
    final d = Map<String, dynamic>.from(await db.rpc('vp_booking_contact', params: {'p_booking': bookingId}));
    if (!c.mounted) return;
    await showDialog(
      context: c,
      builder: (_) => Dialog(
        backgroundColor: C.sf,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26), side: const BorderSide(color: C.gold)),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Stack(clipBehavior: Clip.none, alignment: Alignment.bottomCenter, children: [
              ClipRRect(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
                  child: ShopImage(d['shop_photo_url'] as String?, height: 130)),
              Positioned(
                  bottom: -36,
                  child: Avatar(url: d['barber_photo_url'] as String?, letter: initial(d['barber_name']), size: 76)),
            ]),
            const SizedBox(height: 46),
            const Text('قبل الحلاق حجزك', style: TextStyle(color: C.mu)),
            const SizedBox(height: 4),
            Text('${d['barber_name']}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            Text('${d['shop_name']}', style: const TextStyle(color: C.mu)),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                    backgroundColor: C.gold,
                    foregroundColor: C.ink,
                    minimumSize: const Size.fromHeight(50),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                onPressed: () => callPhone('${d['phone']}'),
                icon: const Icon(Icons.call),
                label: Text('${d['phone']}',
                    textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              ),
            ),
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text('📍 ${d['address']}', textAlign: TextAlign.center, style: const TextStyle(color: C.mu))),
            TextButton(onPressed: () => Navigator.pop(c), child: const Text('حسنًا')),
          ]),
        ),
      ),
    );
  } catch (e) {
    if (c.mounted) snack(c, errText(e));
  }
}

// ============ قائمة الحلاقين (الزبون يختار بحرية) ============
class BarberList extends StatefulWidget {
  const BarberList({super.key});
  @override
  State<BarberList> createState() => _BarberListState();
}

class _BarberListState extends State<BarberList> {
  late Future<List<Map<String, dynamic>>> f = _load();
  Future<List<Map<String, dynamic>>> _load() async => List<Map<String, dynamic>>.from(
      await db.from('vp_barbers_public').select().order('rating', ascending: false));

  @override
  Widget build(BuildContext context) => RefreshIndicator(
        onRefresh: () async {
          setState(() => f = _load());
          await f;
        },
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: f,
          builder: (c, s) {
            if (s.hasError) {
              return ListView(padding: const EdgeInsets.all(24), children: [Text(errText(s.error!))]);
            }
            if (!s.hasData) return const Center(child: CircularProgressIndicator());
            final l = s.data!;
            if (l.isEmpty) {
              return ListView(children: const [SizedBox(height: 200), Center(child: Text('لا يوجد حلاقون متاحون الآن'))]);
            }
            return ListView.builder(
                padding: const EdgeInsets.all(16), itemCount: l.length, itemBuilder: (c, i) => _BarberCard(l[i]));
          },
        ),
      );
}

class _BarberCard extends StatelessWidget {
  const _BarberCard(this.b);
  final Map<String, dynamic> b;
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BarberPage(b: b))),
        child: Container(
          margin: const EdgeInsets.only(bottom: 22),
          decoration: BoxDecoration(color: C.sf, borderRadius: BorderRadius.circular(20), border: Border.all(color: C.ln)),
          child: Column(children: [
            Stack(clipBehavior: Clip.none, children: [
              ClipRRect(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                  child: ShopImage(b['shop_photo_url'] as String?)),
              PositionedDirectional(
                  end: 14,
                  bottom: -30,
                  child: Avatar(url: b['barber_photo_url'] as String?, letter: initial(b['barber_name']), size: 64)),
            ]),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 38, 16, 14),
              child: Row(children: [
                Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${b['shop_name']}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                  Text('${b['barber_name']} · ${b['rating']} ★', style: const TextStyle(color: C.mu)),
                  Text('${b['address']}', style: const TextStyle(color: C.mu, fontSize: 13)),
                ])),
                const Text('1,500 دج', style: TextStyle(color: C.gold2, fontSize: 18, fontWeight: FontWeight.w800)),
              ]),
            ),
          ]),
        ),
      );
}

// ============ صفحة الحلاق: اختيار اليوم والساعة بحرية ============
class BarberPage extends StatefulWidget {
  const BarberPage({super.key, required this.b});
  final Map<String, dynamic> b;
  @override
  State<BarberPage> createState() => _BarberPageState();
}

class _BarberPageState extends State<BarberPage> {
  DateTime? date;
  TimeOfDay? time;
  bool busy = false;

  Future<void> pickDate() async {
    final d = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime.now(),
        lastDate: DateTime.now().add(const Duration(days: 60)));
    if (d != null) setState(() => date = d);
  }

  Future<void> pickTime() async {
    final t = await showTimePicker(context: context, initialTime: const TimeOfDay(hour: 12, minute: 0));
    if (t != null) setState(() => time = t);
  }

  Future<void> send() async {
    final at = DateTime(date!.year, date!.month, date!.day, time!.hour, time!.minute);
    if (at.isBefore(DateTime.now())) {
      snack(context, 'اختر وقتًا في المستقبل');
      return;
    }
    setState(() => busy = true);
    final ok = await run(context,
        () => db.rpc('vp_create_booking', params: {'p_barber': widget.b['id'], 'p_at': at.toUtc().toIso8601String()}));
    if (!mounted) return;
    setState(() => busy = false);
    if (ok) {
      Navigator.pop(context);
      snack(context, 'تم إرسال طلبك، بانتظار قبول الحلاق');
    }
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.b;
    String two(int n) => n.toString().padLeft(2, '0');
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(backgroundColor: Colors.transparent, iconTheme: const IconThemeData(color: Colors.white)),
      body: ListView(padding: EdgeInsets.zero, children: [
        Stack(clipBehavior: Clip.none, children: [
          ClipRRect(
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(28)),
              child: ShopImage(b['shop_photo_url'] as String?, height: 230)),
          PositionedDirectional(
              end: 20,
              bottom: -38,
              child: Avatar(url: b['barber_photo_url'] as String?, letter: initial(b['barber_name']), size: 86)),
        ]),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 50, 20, 30),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${b['shop_name']}', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
            Text('${b['barber_name']} · ${b['rating']} ★', style: const TextStyle(color: C.mu)),
            Text('📍 ${b['address']}', style: const TextStyle(color: C.mu)),
            const SizedBox(height: 22),
            const Text('اختر اليوم والساعة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                  child: GoldButton(
                      date == null ? 'اختر اليوم' : '${date!.day}/${date!.month}/${date!.year}', pickDate,
                      outline: true)),
              const SizedBox(width: 10),
              Expanded(
                  child: GoldButton(time == null ? 'اختر الساعة' : '${two(time!.hour)}:${two(time!.minute)}', pickTime,
                      outline: true)),
            ]),
            const SizedBox(height: 18),
            Panel(
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: const [
              Text('حلاقة كاملة', style: TextStyle(fontSize: 16)),
              Text('1,500 دج', style: TextStyle(color: C.gold2, fontSize: 18, fontWeight: FontWeight.w800)),
            ])),
            GoldButton('أرسل الطلب', date != null && time != null ? send : null, busy: busy),
          ]),
        ),
      ]),
    );
  }
}

// ============ حجوزاتي (تحديث مباشر) ============
class MyBookings extends StatefulWidget {
  const MyBookings({super.key});
  @override
  State<MyBookings> createState() => _MyBookingsState();
}

class _MyBookingsState extends State<MyBookings> {
  late final Stream<List<Map<String, dynamic>>> stream =
      db.from('vp_bookings').stream(primaryKey: ['id']).eq('customer_id', db.auth.currentUser!.id);

  @override
  Widget build(BuildContext context) => StreamBuilder<List<Map<String, dynamic>>>(
        stream: stream,
        builder: (c, s) {
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final l = [...s.data!]..sort((a, b) => '${b['scheduled_at']}'.compareTo('${a['scheduled_at']}'));
          if (l.isEmpty) return const Center(child: Text('لا توجد حجوزات بعد'));
          return ListView(padding: const EdgeInsets.all(16), children: [for (final k in l) _tile(k)]);
        },
      );

  Widget _tile(Map<String, dynamic> k) {
    final st = '${k['status']}', id = '${k['id']}';
    return Panel(
      child: Column(children: [
        Row(children: [
          Avatar(url: k['barber_photo_url'] as String?, letter: initial(k['barber_name']), size: 46),
          const SizedBox(width: 12),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${k['shop_name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            Text('${k['barber_name']}', style: const TextStyle(color: C.mu)),
            Text(fmtDt(k['scheduled_at']), style: const TextStyle(color: C.mu), textDirection: TextDirection.ltr),
          ])),
          StatusChip(st),
        ]),
        const Divider(color: C.ln, height: 24),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: const [
          Text('السعر'),
          Text('1,500 دج', style: TextStyle(color: C.gold2, fontWeight: FontWeight.w800)),
        ]),
        if (st == 'accepted' || st == 'pending') const SizedBox(height: 12),
        if (st == 'accepted')
          Row(children: [
            Expanded(child: GoldButton('بيانات الحلاق', () => showContact(context, id))),
            const SizedBox(width: 10),
            Expanded(
                child: GoldButton('إلغاء',
                    () => run(context, () => db.rpc('vp_cancel_booking', params: {'p_booking': id}), ok: 'تم الإلغاء'),
                    danger: true)),
          ]),
        if (st == 'pending')
          GoldButton('إلغاء الحجز',
              () => run(context, () => db.rpc('vp_cancel_booking', params: {'p_booking': id}), ok: 'تم الإلغاء'),
              danger: true),
      ]),
    );
  }
}
