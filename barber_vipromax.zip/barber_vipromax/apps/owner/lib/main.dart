import 'dart:async';

import 'package:core/core.dart';
import 'package:flutter/material.dart';

void main() => bootstrap(const VpApp(title: 'BARBER VIPROMAX OWNER', home: Gate()));

// ============ بوابة المالك: لا يدخل إلا حساب دوره owner ============
class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  Future<bool> _isOwner() async {
    final u = db.auth.currentUser;
    if (u == null) return false;
    final p = await db.from('vp_profiles').select('role').eq('id', u.id).maybeSingle();
    return p != null && p['role'] == 'owner';
  }

  late Future<bool> f = _isOwner();
  void reload() => setState(() => f = _isOwner());

  @override
  Widget build(BuildContext context) => FutureBuilder<bool>(
        future: f,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) {
            return const Scaffold(body: Center(child: Logo(size: 90)));
          }
          if (s.data == true) {
            return OwnerHome(onLogout: () async {
              await db.auth.signOut();
              reload();
            });
          }
          return LoginScreen(onDone: reload);
        },
      );
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.onDone});
  final VoidCallback onDone;
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController(), pass = TextEditingController();
  bool busy = false;

  Future<void> go() async {
    setState(() => busy = true);
    try {
      await db.auth.signInWithPassword(email: email.text.trim(), password: pass.text);
      final u = db.auth.currentUser!;
      final p = await db.from('vp_profiles').select('role').eq('id', u.id).maybeSingle();
      if (p == null || p['role'] != 'owner') {
        await db.auth.signOut();
        throw 'هذا الحساب ليس حساب المالك';
      }
      widget.onDone();
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: ListView(padding: const EdgeInsets.all(24), children: [
            const SizedBox(height: 40),
            const Center(child: Logo(size: 96)),
            const SizedBox(height: 10),
            const Center(
                child: Text('BARBER VIPROMAX',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: 3, color: C.gold2))),
            const Center(child: Text('تطبيق المالك', style: TextStyle(color: C.mu))),
            const SizedBox(height: 28),
            Field('البريد الإلكتروني', email, keyboard: TextInputType.emailAddress),
            Field('كلمة السر', pass, obscure: true),
            GoldButton('دخول المالك', go, busy: busy),
          ]),
        ),
      );
}

// ============ الرئيسية ============
class OwnerHome extends StatefulWidget {
  const OwnerHome({super.key, required this.onLogout});
  final VoidCallback onLogout;
  @override
  State<OwnerHome> createState() => _OwnerHomeState();
}

class _OwnerHomeState extends State<OwnerHome> {
  int tab = 0;
  StreamSubscription? sub;
  final seen = <String>{};
  bool first = true;

  @override
  void initState() {
    super.initState();
    // إشعار فوري عند: حلاق جديد، أو اتفاق زبون مع حلاق
    sub = db.from('vp_notifications').stream(primaryKey: ['id']).eq('user_id', db.auth.currentUser!.id).listen((rows) {
      for (final r in rows) {
        final id = '${r['id']}';
        if (!first && !seen.contains(id) && mounted) snack(context, '${r['title']}: ${r['body']}');
        seen.add(id);
      }
      first = false;
    });
  }

  @override
  void dispose() {
    sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [const Dashboard(), const Customers(), const Barbers(), const Bookings()];
    return Scaffold(
      appBar: AppBar(
        title: const BrandTitle('تطبيق المالك'),
        actions: [IconButton(onPressed: widget.onLogout, icon: const Icon(Icons.logout, color: C.mu))],
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'اللوحة'),
          NavigationDestination(icon: Icon(Icons.people_outline), label: 'الزبائن'),
          NavigationDestination(icon: Icon(Icons.content_cut), label: 'الحلاقون'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'الطلبات'),
        ],
      ),
    );
  }
}

/// قائمة قابلة للتحديث بالسحب، تعيد تحميل بياناتها
class Loader<T> extends StatefulWidget {
  const Loader({super.key, required this.load, required this.builder});
  final Future<T> Function() load;
  final Widget Function(BuildContext, T, VoidCallback reload) builder;
  @override
  State<Loader<T>> createState() => _LoaderState<T>();
}

class _LoaderState<T> extends State<Loader<T>> {
  late Future<T> f = widget.load();
  void reload() => setState(() => f = widget.load());
  @override
  Widget build(BuildContext context) => RefreshIndicator(
        onRefresh: () async {
          reload();
          await f;
        },
        child: FutureBuilder<T>(
          future: f,
          builder: (c, s) {
            if (s.hasError) return ListView(padding: const EdgeInsets.all(24), children: [Text(errText(s.error!))]);
            if (!s.hasData) return const Center(child: CircularProgressIndicator());
            return widget.builder(c, s.data as T, reload);
          },
        ),
      );
}

List<Map<String, dynamic>> rows(dynamic d) => List<Map<String, dynamic>>.from(d as List);

// ============ لوحة المالك ============
class Dashboard extends StatelessWidget {
  const Dashboard({super.key});
  @override
  Widget build(BuildContext context) => Loader<Map<String, dynamic>>(
        load: () async {
          final fin = rows(await db.from('vp_finance').select());
          final cust = rows(await db.from('vp_profiles').select('id').eq('role', 'customer'));
          final pend = rows(await db.from('vp_barbers').select('id').eq('status', 'pending'));
          final appr = rows(await db.from('vp_barbers').select('id').eq('status', 'approved'));
          final nt = rows(await db
              .from('vp_notifications')
              .select()
              .eq('user_id', db.auth.currentUser!.id)
              .order('created_at', ascending: false)
              .limit(20));
          num sum(String k) => fin.fold<num>(0, (a, r) => a + (r[k] as num));
          return {
            'income': sum('platform_total'),
            'paid': sum('paid_to_owner'),
            'remaining': sum('remaining'),
            'services': sum('services'),
            'customers': cust.length,
            'barbers': appr.length,
            'pending': pend.length,
            'nt': nt,
          };
        },
        builder: (c, d, reload) {
          Widget stat(String l, String v, {Color? col}) => Expanded(
                child: Panel(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(l, style: const TextStyle(color: C.mu, fontSize: 13)),
                  const SizedBox(height: 4),
                  Text(v, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: col)),
                ])),
              );
          final nt = d['nt'] as List<Map<String, dynamic>>;
          return ListView(padding: const EdgeInsets.all(16), children: [
            const Text('إجمالي دخل المنصة', style: TextStyle(color: C.mu)),
            Text(money(d['income'] as num),
                style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w800, color: C.gold2)),
            Text('من ${(d['services'] as num).toInt()} خدمة مكتملة', style: const TextStyle(color: C.mu)),
            const SizedBox(height: 14),
            Row(children: [
              stat('تم تحصيله', money(d['paid'] as num)),
              const SizedBox(width: 10),
              stat('المتبقي', money(d['remaining'] as num), col: C.gold2),
            ]),
            Row(children: [
              stat('الزبائن', '${d['customers']}'),
              const SizedBox(width: 10),
              stat('الحلاقون', '${d['barbers']}'),
            ]),
            if ((d['pending'] as int) > 0)
              Panel(
                  child: Row(children: [
                Expanded(child: Text('${d['pending']} طلب انضمام ينتظر موافقتك', style: const TextStyle(fontWeight: FontWeight.w800))),
                const StatusChip('pending'),
              ])),
            const SizedBox(height: 8),
            const Text('الإشعارات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            if (nt.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('لا إشعارات بعد'))),
            for (final n in nt)
              Panel(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${n['title']}', style: const TextStyle(fontWeight: FontWeight.w800)),
                if ('${n['body']}'.isNotEmpty) Text('${n['body']}', style: const TextStyle(color: C.mu)),
                Text(fmtDt(n['created_at']), style: const TextStyle(color: C.mu, fontSize: 12), textDirection: TextDirection.ltr),
              ])),
          ]);
        },
      );
}

// ============ الزبائن بأسمائهم وأرقامهم ============
class Customers extends StatelessWidget {
  const Customers({super.key});
  @override
  Widget build(BuildContext context) => Loader<List<Map<String, dynamic>>>(
        load: () async => rows(await db.from('vp_profiles').select().eq('role', 'customer').order('created_at', ascending: false)),
        builder: (c, l, reload) => ListView(padding: const EdgeInsets.all(16), children: [
          Text('${l.length} زبون مشترك', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          for (final p in l)
            Panel(
                child: Row(children: [
              Avatar(url: p['avatar_url'] as String?, letter: initial(p['full_name']), size: 48),
              const SizedBox(width: 12),
              Expanded(child: Text('${p['full_name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
              PhoneLink('${p['phone']}'),
            ])),
        ]),
      );
}

// ============ الحلاقون: موافقة / رفض / إيقاف / تسوية ============
class Barbers extends StatelessWidget {
  const Barbers({super.key});

  Future<void> payDialog(BuildContext c, Map<String, dynamic> b, num remaining, VoidCallback reload) async {
    final a = TextEditingController(text: remaining.toInt().toString());
    final ok = await showDialog<bool>(
        context: c,
        builder: (_) => AlertDialog(
              backgroundColor: C.sf,
              title: Text('دفعة من ${b['barber_name']}'),
              content: Field('المبلغ (دج)', a, keyboard: TextInputType.number),
              actions: [
                TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
                TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('تسجيل')),
              ],
            ));
    final v = int.tryParse(a.text) ?? 0;
    if (ok != true || v <= 0 || !c.mounted) return;
    final done = await run(c, () => db.rpc('vp_record_settlement', params: {'p_barber': b['id'], 'p_amount': v}), ok: 'تم تسجيل الدفعة');
    if (done) reload();
  }

  @override
  Widget build(BuildContext context) => Loader<Map<String, dynamic>>(
        load: () async {
          final bs = rows(await db.from('vp_barbers').select().order('created_at', ascending: false));
          final fin = rows(await db.from('vp_finance').select());
          return {'bs': bs, 'fin': {for (final r in fin) '${r['barber_id']}': r}};
        },
        builder: (c, d, reload) {
          final bs = d['bs'] as List<Map<String, dynamic>>;
          final fin = d['fin'] as Map<String, Map<String, dynamic>>;
          Future<void> setStatus(Map<String, dynamic> b, String s, String msg) async {
            final ok = await run(c, () => db.rpc('vp_set_barber_status', params: {'p_barber': b['id'], 'p_status': s}), ok: msg);
            if (ok) reload();
          }

          Widget head(Map<String, dynamic> b) => Row(children: [
                Avatar(url: b['barber_photo_url'] as String?, letter: initial(b['barber_name']), size: 54),
                const SizedBox(width: 12),
                Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${b['barber_name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  Text('${b['shop_name']}', style: const TextStyle(color: C.mu)),
                  Text('${b['address']}', style: const TextStyle(color: C.mu, fontSize: 12)),
                ])),
                StatusChip('${b['status']}'),
              ]);

          final pend = bs.where((b) => b['status'] == 'pending').toList();
          final rest = bs.where((b) => b['status'] != 'pending').toList();
          return ListView(padding: const EdgeInsets.all(16), children: [
            if (pend.isNotEmpty) ...[
              const Text('طلبات الانضمام', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              for (final b in pend)
                Panel(
                    child: Column(children: [
                  ShopImageRounded(b['shop_photo_url'] as String?),
                  const SizedBox(height: 10),
                  head(b),
                  Align(alignment: AlignmentDirectional.centerStart, child: PhoneLink('${b['phone']}')),
                  Row(children: [
                    Expanded(child: GoldButton('موافقة', () => setStatus(b, 'approved', 'تمت الموافقة'))),
                    const SizedBox(width: 10),
                    Expanded(child: GoldButton('رفض', () => setStatus(b, 'rejected', 'تم الرفض'), danger: true)),
                  ]),
                ])),
              const SizedBox(height: 10),
            ],
            const Text('الحلاقون', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            for (final b in rest)
              Panel(
                  child: Column(children: [
                head(b),
                Align(alignment: AlignmentDirectional.centerStart, child: PhoneLink('${b['phone']}')),
                Builder(builder: (_) {
                  final f = fin['${b['id']}'] ?? {};
                  final rem = (f['remaining'] ?? 0) as num;
                  return Column(children: [
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Text('${(f['services'] ?? 0)} خدمة · مستحقاته ${money((f['barber_total'] ?? 0) as num)}',
                          style: const TextStyle(color: C.mu, fontSize: 13)),
                    ]),
                    const SizedBox(height: 4),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      const Text('المتبقي للمالك'),
                      Text(money(rem), style: const TextStyle(color: C.gold2, fontWeight: FontWeight.w800)),
                    ]),
                    const SizedBox(height: 10),
                    Row(children: [
                      Expanded(child: GoldButton('تسجيل دفعة', rem > 0 ? () => payDialog(c, b, rem, reload) : null)),
                      const SizedBox(width: 10),
                      Expanded(
                          child: GoldButton(b['status'] == 'approved' ? 'إيقاف' : 'تفعيل',
                              () => setStatus(b, b['status'] == 'approved' ? 'blocked' : 'approved',
                                  b['status'] == 'approved' ? 'تم الإيقاف' : 'تم التفعيل'),
                              outline: true)),
                    ]),
                  ]);
                }),
              ])),
          ]);
        },
      );
}

class ShopImageRounded extends StatelessWidget {
  const ShopImageRounded(this.url, {super.key});
  final String? url;
  @override
  Widget build(BuildContext context) => ClipRRect(borderRadius: BorderRadius.circular(14), child: ShopImage(url, height: 120));
}

// ============ كل الطلبات بدقة: الزبون والحلاق وأرقامهما ============
class Bookings extends StatelessWidget {
  const Bookings({super.key});
  @override
  Widget build(BuildContext context) => Loader<List<Map<String, dynamic>>>(
        load: () async => rows(await db.from('vp_bookings').select().order('created_at', ascending: false).limit(200)),
        builder: (c, l, reload) => ListView(padding: const EdgeInsets.all(16), children: [
          Text('${l.length} طلب', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          for (final k in l)
            Panel(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(k['source'] == 'walkin' ? 'زبون بدون حجز' : fmtDt(k['scheduled_at']), textDirection: TextDirection.ltr, style: const TextStyle(color: C.gold2, fontWeight: FontWeight.w800))),
                StatusChip('${k['status']}'),
              ]),
              const Divider(color: C.ln, height: 20),
              Row(children: [
                Avatar(url: k['customer_photo_url'] as String?, letter: initial(k['customer_name']), size: 40),
                const SizedBox(width: 10),
                Expanded(child: Text('الزبون: ${k['customer_name']}')),
                PhoneLink('${k['customer_phone']}'),
              ]),
              Row(children: [
                Avatar(url: k['barber_photo_url'] as String?, letter: initial(k['barber_name']), size: 40),
                const SizedBox(width: 10),
                Expanded(child: Text('الحلاق: ${k['barber_name']}')),
                PhoneLink('${k['barber_phone']}'),
              ]),
            ])),
        ]),
      );
}
