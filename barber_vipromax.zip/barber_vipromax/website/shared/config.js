// يُملأ تلقائيًا عند البناء من أسرار GitHub (SUPABASE_URL و SUPABASE_ANON_KEY)
window.VP_SB = { url: 'PUT_YOUR_SUPABASE_URL', key: 'PUT_YOUR_SUPABASE_ANON_KEY' };
