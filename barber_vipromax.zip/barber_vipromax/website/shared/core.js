/* BARBER VIPROMAX - نواة مشتركة لتطبيقات الويب (زبائن + حلاقين) */
(function () {
  'use strict';
  var C = window.VP_SB || {};
  var sb = window.supabase.createClient(C.url, C.key, {
    auth: { persistSession: true, autoRefreshToken: true, storageKey: 'vp-auth-' + (window.VP_APP || 'x') }
  });
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var money = function (n) { return Number(n || 0).toLocaleString('en-US') + ' دج'; };
  var pad = function (n) { return String(n).padStart(2, '0'); };
  var fmtDt = function (iso) { var d = new Date(iso); return d.getDate() + '/' + (d.getMonth() + 1) + ' - ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); };
  var ST = { pending: ['بانتظار القبول', 'wait'], accepted: ['مؤكد', 'ok'], completed: ['اكتملت', 'ok'], rejected: ['مرفوض', 'no'], cancelled: ['ملغى', 'no'], approved: ['معتمد', 'ok'], blocked: ['موقوف', 'no'] };
  var chip = function (s) { var x = ST[s]; return '<span class="chip ' + (x ? x[1] : '') + '">' + (x ? x[0] : esc(s)) + '</span>'; };
  var initial = function (s) { s = String(s || '').trim(); return s ? s.charAt(0) : '?'; };
  var avatar = function (url, letter, size) {
    size = size || 52;
    return url ? '<img class="av" style="width:' + size + 'px;height:' + size + 'px" src="' + esc(url) + '" alt="">'
      : '<div class="av" style="width:' + size + 'px;height:' + size + 'px;font-size:' + Math.round(size * 0.4) + 'px">' + esc(letter) + '</div>';
  };
  var shopImg = function (url, h) {
    h = h || 130;
    return url ? '<img class="shop" style="height:' + h + 'px" src="' + esc(url) + '" alt="">' : '<div class="shop ph" style="height:' + h + 'px">✂</div>';
  };
  var ERR = {
    'barber not available': 'الحلاق غير متاح حاليًا', 'time is in the past': 'اختر وقتًا في المستقبل', 'booking already handled': 'تمت معالجة هذا الحجز',
    'cannot cancel': 'لا يمكن إلغاء هذا الحجز', 'must be accepted first': 'يجب قبول الحجز أولًا', 'Invalid login credentials': 'رقم الهاتف أو كلمة السر غير صحيحة',
    'Email not confirmed': 'الحساب غير مؤكد: أوقف Confirm email في إعدادات Supabase', 'Anonymous sign-ins are disabled': 'فعّل Anonymous sign-ins في إعدادات Supabase',
    'Password should be at least': 'كلمة السر قصيرة (6 أحرف على الأقل)'
  };
  function errText(e) {
    var m = (e && e.message) || String(e);
    for (var k in ERR) { if (m.indexOf(k) >= 0) return ERR[k]; }
    if (m.indexOf('duplicate key') >= 0) return 'هذا الموعد محجوز عند الحلاق، اختر وقتًا آخر';
    if (/Failed to fetch|NetworkError|Load failed/i.test(m)) return 'لا يوجد اتصال بالإنترنت';
    return m;
  }
  var toastT;
  function toast(msg) {
    var old = $('.toast'); if (old) old.remove();
    var t = document.createElement('div'); t.className = 'toast'; t.textContent = msg; document.body.appendChild(t);
    clearTimeout(toastT); toastT = setTimeout(function () { t.remove(); }, 2600);
  }
  function modal(html, opts) {
    opts = opts || {};
    var bg = document.createElement('div'); bg.className = 'mbg' + (opts.center ? ' center' : '');
    bg.innerHTML = '<div class="sheet">' + html + '</div>'; document.body.appendChild(bg);
    var close = function () { bg.remove(); if (opts.onClose) opts.onClose(); };
    bg.addEventListener('click', function (e) { if (e.target === bg) close(); });
    var x = bg.querySelector('[data-close]'); if (x) x.addEventListener('click', close);
    return { el: bg, close: close, $: function (s) { return bg.querySelector(s); } };
  }
  function resizeImage(file, max) {
    max = max || 1000;
    return new Promise(function (res, rej) {
      var img = new Image(), url = URL.createObjectURL(file);
      img.onload = function () {
        var k = Math.min(1, max / Math.max(img.width, img.height)), c = document.createElement('canvas');
        c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        c.toBlob(function (b) { URL.revokeObjectURL(url); b ? res(b) : rej(new Error('تعذّر قراءة الصورة')); }, 'image/jpeg', 0.82);
      };
      img.onerror = function () { rej(new Error('تعذّر قراءة الصورة')); };
      img.src = url;
    });
  }
  async function uploadPhoto(blob, tag) {
    var s = (await sb.auth.getSession()).data.session; if (!s) throw new Error('غير مسجّل');
    var path = s.user.id + '/' + tag + '-' + Date.now() + '.jpg';
    var up = await sb.storage.from('vp-photos').upload(path, blob, { contentType: 'image/jpeg', upsert: true });
    if (up.error) throw up.error;
    return sb.storage.from('vp-photos').getPublicUrl(path).data.publicUrl;
  }
  function callPhone(p) { window.location.href = 'tel:' + String(p).replace(/\s/g, ''); }
  function installHint(host) {
    var ios = /iPhone|iPad|iPod/i.test(navigator.userAgent);
    var standalone = window.navigator.standalone === true || (window.matchMedia && matchMedia('(display-mode: standalone)').matches);
    if (!ios || standalone || localStorage.getItem('vp-hint')) return;
    var d = document.createElement('div'); d.className = 'hint';
    d.innerHTML = '<span>ثبّت التطبيق: اضغط زر المشاركة ⬆︎ ثم «إضافة إلى الشاشة الرئيسية»</span><button aria-label="إغلاق">✕</button>';
    d.querySelector('button').onclick = function () { localStorage.setItem('vp-hint', '1'); d.remove(); };
    host.insertBefore(d, host.firstChild);
  }
  if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) { navigator.serviceWorker.register('sw.js').catch(function () { }); }
  window.VP = { sb: sb, $: $, esc: esc, money: money, fmtDt: fmtDt, chip: chip, avatar: avatar, shopImg: shopImg, errText: errText, toast: toast, modal: modal, resizeImage: resizeImage, uploadPhoto: uploadPhoto, initial: initial, callPhone: callPhone, installHint: installHint, pad: pad };
})();
