// خدمة بسيطة: تخزين مؤقت لملفات الواجهة فقط (لا نخزّن أي بيانات من قاعدة البيانات)
var V='vp-shell-v1', FILES=['./','index.html','app.js','manifest.webmanifest','../shared/ui.css','../shared/core.js','../shared/icons/logo.png'];
self.addEventListener('install',function(e){e.waitUntil(caches.open(V).then(function(c){return c.addAll(FILES)}).catch(function(){}));self.skipWaiting()});
self.addEventListener('activate',function(e){e.waitUntil(caches.keys().then(function(ks){return Promise.all(ks.filter(function(k){return k!==V}).map(function(k){return caches.delete(k)}))}));self.clients.claim()});
self.addEventListener('fetch',function(e){
  var r=e.request; if(r.method!=='GET') return; var u=new URL(r.url);
  if(u.origin!==location.origin) return;               // Supabase والخطوط: مباشرة من الشبكة
  if(u.pathname.indexOf('config.js')>=0) return;      // الإعدادات دائمًا من الشبكة
  e.respondWith(fetch(r).then(function(res){var cp=res.clone();caches.open(V).then(function(c){c.put(r,cp)});return res}).catch(function(){return caches.match(r)}));
});
