/* تطبيق الزبائن (ويب/آيفون) - نفس قاعدة البيانات ونفس خصائص تطبيق أندرويد */
(function () {
  'use strict';
  var V = VP, sb = V.sb, esc = V.esc, root = document.getElementById('app');
  var S = { me: null, tab: 0, barbers: [], bookings: [], seen: {}, first: true, photo: null, contactOpen: false };
  var uid = null, chan = null, pollT = null;

  function shell(inner) {
    root.innerHTML =
      '<div class="top"><div class="brand"><img src="../shared/icons/logo.png" alt=""><div><b>BARBER VIPROMAX</b><small>تطبيق الزبائن</small></div></div>' +
      '<button class="iconbtn" id="logout" aria-label="خروج">⎋</button></div>' +
      '<main id="main">' + inner + '</main>' +
      '<nav><button data-tab="0" class="' + (S.tab === 0 ? 'on' : '') + '">الحلاقون</button><button data-tab="1" class="' + (S.tab === 1 ? 'on' : '') + '">حجوزاتي</button></nav>';
    V.installHint(root);
    V.$('#logout').onclick = logout;
    root.querySelectorAll('nav button').forEach(function (b) { b.onclick = function () { S.tab = +b.dataset.tab; render(); }; });
  }

  /* ---------- تسجيل الدخول ---------- */
  function viewLogin() {
    root.innerHTML =
      '<div class="login"><img class="logo" src="../shared/icons/logo.png" alt=""><div class="brandname">BARBER VIPROMAX</div><div class="sub">تطبيق الزبائن</div>' +
      '<label class="photo"><span id="prev">📷</span><small>أضف صورتك (اختياري)</small><input id="pin" type="file" accept="image/*" hidden></label>' +
      '<input id="nm" class="inp" placeholder="الاسم" autocomplete="name">' +
      '<input id="ph" class="inp ltr" style="text-align:right" inputmode="tel" placeholder="رقم الهاتف" autocomplete="tel">' +
      '<button class="btn" id="go">دخول</button></div>';
    V.installHint(root);
    V.$('#pin').onchange = async function (e) {
      var f = e.target.files[0]; if (!f) return;
      try { S.photo = await V.resizeImage(f, 700); V.$('#prev').innerHTML = '<img src="' + URL.createObjectURL(S.photo) + '" alt="">'; } catch (er) { V.toast(V.errText(er)); }
    };
    V.$('#go').onclick = doLogin;
  }
  async function doLogin() {
    var n = V.$('#nm').value.trim(), p = V.$('#ph').value.trim(), btn = V.$('#go');
    if (!n || p.replace(/\D/g, '').length < 9) { V.toast('أدخل الاسم ورقم هاتف صحيح'); return; }
    btn.disabled = true; btn.textContent = '...';
    try {
      var s = (await sb.auth.getSession()).data.session;
      if (!s) { var r = await sb.auth.signInAnonymously(); if (r.error) throw r.error; }
      var url = null; if (S.photo) url = await V.uploadPhoto(S.photo, 'me');
      var e2 = (await sb.rpc('vp_ensure_profile', { p_role: 'customer', p_name: n, p_phone: p, p_avatar: url })).error; if (e2) throw e2;
      await boot();
    } catch (er) { V.toast(V.errText(er)); btn.disabled = false; btn.textContent = 'دخول'; }
  }
  async function logout() {
    if (chan) { sb.removeChannel(chan); chan = null; } clearInterval(pollT);
    await sb.auth.signOut(); S.me = null; S.bookings = []; S.seen = {}; S.first = true; S.photo = null; viewLogin();
  }

  /* ---------- البيانات ---------- */
  async function loadBarbers() {
    var r = await sb.from('vp_barbers_public').select('*').order('rating', { ascending: false });
    if (r.error) throw r.error; S.barbers = r.data || [];
  }
  async function loadBookings(silent) {
    var r = await sb.from('vp_bookings').select('*').eq('customer_id', uid).order('scheduled_at', { ascending: false });
    if (r.error) { if (!silent) V.toast(V.errText(r.error)); return; }
    S.bookings = r.data || [];
    S.bookings.forEach(function (b) {
      if (!S.first && S.seen[b.id] === 'pending' && b.status === 'accepted') showContact(b.id);
      S.seen[b.id] = b.status;
    });
    S.first = false;
    if (S.tab === 1 && !S.contactOpen) paintBookings();
  }
  function subscribe() {
    if (chan) sb.removeChannel(chan);
    chan = sb.channel('vp-c-' + uid).on('postgres_changes', { event: '*', schema: 'public', table: 'vp_bookings', filter: 'customer_id=eq.' + uid }, function () { loadBookings(true); }).subscribe();
    clearInterval(pollT); pollT = setInterval(function () { if (document.visibilityState === 'visible') loadBookings(true); }, 15000);
  }
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible' && uid) loadBookings(true); });

  /* ---------- العرض ---------- */
  function render() {
    shell('<div class="spin"><img src="../shared/icons/logo.png" alt=""></div>');
    if (S.tab === 0) viewBarbers(); else { paintBookings(); loadBookings(true); }
  }
  async function viewBarbers() {
    try { await loadBarbers(); } catch (e) { V.$('#main').innerHTML = '<div class="empty">' + esc(V.errText(e)) + '</div>'; return; }
    var h = '<h1>اختر حلاقك بحرية</h1><p class="sub">سعر موحد 1,500 دج، وأنت تحدد اليوم والساعة</p>';
    if (!S.barbers.length) h += '<div class="empty">لا يوجد حلاقون متاحون الآن</div>';
    S.barbers.forEach(function (b, i) {
      h += '<div class="bc" data-i="' + i + '">' + V.shopImg(b.shop_photo_url, 130) + V.avatar(b.barber_photo_url, V.initial(b.barber_name), 62) +
        '<div class="bb"><div class="grow"><div class="nm">' + esc(b.shop_name) + '</div><div class="mt">' + esc(b.barber_name) + ' · ' + esc(b.rating) + ' ★</div><div class="mt">' + esc(b.address) + '</div></div><div class="pr">1,500 دج</div></div></div>';
    });
    h += '<button class="btn ghost" id="refresh">تحديث القائمة</button>';
    V.$('#main').innerHTML = h;
    root.querySelectorAll('.bc').forEach(function (c) { c.onclick = function () { openBarber(S.barbers[+c.dataset.i]); }; });
    V.$('#refresh').onclick = viewBarbers;
  }
  function paintBookings() {
    var m = V.$('#main'); if (!m) return;
    var h = '<h1>حجوزاتي</h1><p class="sub">تصلك بيانات الحلاق فور قبوله</p>';
    if (!S.bookings.length) h += '<div class="empty">لا توجد حجوزات بعد.<br>اختر حلاقًا واحجز أول موعد.</div>';
    S.bookings.forEach(function (k) {
      h += '<div class="card"><div class="row">' + V.avatar(k.barber_photo_url, V.initial(k.barber_name), 46) +
        '<div class="grow"><div class="nm" style="font-size:16px">' + esc(k.shop_name) + '</div><div class="mt">' + esc(k.barber_name) + '</div><div class="mt ltr" style="text-align:right">' + V.fmtDt(k.scheduled_at) + '</div></div>' + V.chip(k.status) + '</div>' +
        '<div class="line" style="margin-top:8px"><span>السعر</span><b>1,500 دج</b></div>';
      if (k.status === 'accepted') h += '<div class="acts"><button class="btn sm" data-contact="' + k.id + '">بيانات الحلاق</button><button class="btn sm red" data-cancel="' + k.id + '">إلغاء</button></div>';
      else if (k.status === 'pending') h += '<div class="acts"><button class="btn sm red" data-cancel="' + k.id + '">إلغاء الحجز</button></div>';
      h += '</div>';
    });
    m.innerHTML = h;
    m.querySelectorAll('[data-contact]').forEach(function (b) { b.onclick = function () { showContact(b.dataset.contact); }; });
    m.querySelectorAll('[data-cancel]').forEach(function (b) { b.onclick = function () { cancelBooking(b.dataset.cancel); }; });
  }
  async function cancelBooking(id) {
    if (!confirm('هل تريد إلغاء هذا الحجز؟')) return;
    var r = await sb.rpc('vp_cancel_booking', { p_booking: id });
    if (r.error) V.toast(V.errText(r.error)); else { V.toast('تم الإلغاء'); loadBookings(); }
  }

  /* ---------- صفحة الحلاق + الحجز ---------- */
  function openBarber(b) {
    var today = new Date(), iso = today.getFullYear() + '-' + V.pad(today.getMonth() + 1) + '-' + V.pad(today.getDate());
    var m = V.modal(
      '<div class="hero"><button class="close" data-close aria-label="إغلاق">✕</button>' + V.shopImg(b.shop_photo_url, 210) + V.avatar(b.barber_photo_url, V.initial(b.barber_name), 84) + '</div>' +
      '<div class="pad" style="padding-top:46px"><div class="nm" style="font-size:24px">' + esc(b.shop_name) + '</div><div class="mt">' + esc(b.barber_name) + ' · ' + esc(b.rating) + ' ★</div><div class="mt">📍 ' + esc(b.address) + '</div>' +
      '<h2>اختر اليوم والساعة</h2><input id="d" class="inp" type="date" min="' + iso + '"><input id="t" class="inp" type="time" value="12:00">' +
      '<div class="card row" style="margin-top:6px"><div class="grow">حلاقة كاملة</div><div class="pr">1,500 دج</div></div>' +
      '<button class="btn" id="send" disabled>أرسل الطلب</button></div>');
    var d = m.$('#d'), t = m.$('#t'), btn = m.$('#send');
    var chk = function () { btn.disabled = !(d.value && t.value); }; d.oninput = t.oninput = chk;
    btn.onclick = async function () {
      var at = new Date(d.value + 'T' + t.value);
      if (isNaN(at) || at < new Date()) { V.toast('اختر وقتًا في المستقبل'); return; }
      btn.disabled = true; btn.textContent = '...';
      var r = await sb.rpc('vp_create_booking', { p_barber: b.id, p_at: at.toISOString() });
      if (r.error) { V.toast(V.errText(r.error)); btn.disabled = false; btn.textContent = 'أرسل الطلب'; return; }
      m.close(); S.tab = 1; V.toast('تم إرسال طلبك، بانتظار قبول الحلاق'); render();
    };
  }

  /* ---------- بيانات الحلاق بعد القبول ---------- */
  async function showContact(id) {
    if (S.contactOpen) return;
    var r = await sb.rpc('vp_booking_contact', { p_booking: id });
    if (r.error) { V.toast(V.errText(r.error)); return; }
    var d = r.data; S.contactOpen = true;
    var m = V.modal(
      '<div style="position:relative">' + V.shopImg(d.shop_photo_url, 130) + '<div style="position:absolute;left:50%;bottom:-38px;transform:translateX(-50%)">' + V.avatar(d.barber_photo_url, V.initial(d.barber_name), 76) + '</div></div>' +
      '<div class="pad" style="padding-top:50px;text-align:center"><div class="mt">قبل الحلاق حجزك</div><div class="nm" style="font-size:24px;margin-top:4px">' + esc(d.barber_name) + '</div><div class="mt">' + esc(d.shop_name) + '</div>' +
      '<a class="call" href="tel:' + esc(String(d.phone).replace(/\s/g, '')) + '">📞 ' + esc(d.phone) + '</a><div class="mt" style="margin-bottom:14px">📍 ' + esc(d.address) + '</div><button class="btn ghost" data-close>حسنًا</button></div>',
      { center: true, onClose: function () { S.contactOpen = false; if (S.tab === 1) paintBookings(); } });
    if (navigator.vibrate) navigator.vibrate([120, 60, 120]);
    return m;
  }

  /* ---------- الإقلاع ---------- */
  async function boot() {
    var s = (await sb.auth.getSession()).data.session;
    if (!s) { viewLogin(); return; }
    uid = s.user.id;
    var p = await sb.from('vp_profiles').select('*').eq('id', uid).maybeSingle();
    if (!p.data) { viewLogin(); return; }
    S.me = p.data; S.first = true; await loadBookings(true); subscribe(); render();
  }
  boot().catch(function (e) { root.innerHTML = '<div class="empty">' + esc(V.errText(e)) + '<br><br><button class="btn" onclick="location.reload()">إعادة المحاولة</button></div>'; });
})();
