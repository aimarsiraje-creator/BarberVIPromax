/* تطبيق الحلاقين (ويب/آيفون) - نفس قاعدة البيانات ونفس خصائص تطبيق أندرويد */
(function () {
  'use strict';
  var V = VP, sb = V.sb, esc = V.esc, root = document.getElementById('app');
  var S = { b: null, tab: 0, reg: true, bookings: [], first: true, known: {}, photos: {}, fin: {}, rows: [] };
  var uid = null, chBook = null, chBarb = null, pollT = null;

  function emailOf(phone) { return 'vp' + String(phone).replace(/\D/g, '') + '@gmail.com'; }

  /* ---------- الدخول / التسجيل ---------- */
  function viewAuth() {
    var reg = S.reg;
    root.innerHTML =
      '<div class="login"><img class="logo" src="../shared/icons/logo.png" alt=""><div class="brandname">BARBER VIPROMAX</div><div class="sub">تطبيق الحلاقين</div>' +
      '<div class="seg"><button data-r="1" class="' + (reg ? 'on' : '') + '">حلاق جديد</button><button data-r="0" class="' + (!reg ? 'on' : '') + '">دخول</button></div>' +
      (reg ? '<input id="n" class="inp" placeholder="اسم الحلاق"><input id="sh" class="inp" placeholder="اسم المحل"><input id="ad" class="inp" placeholder="العنوان">' : '') +
      '<input id="ph" class="inp ltr" style="text-align:right" inputmode="tel" placeholder="رقم الهاتف"><input id="pw" class="inp" type="password" placeholder="كلمة السر" autocomplete="' + (reg ? 'new-password' : 'current-password') + '">' +
      (reg ? '<label class="upl" id="lb"><span>صورة الحلاق</span><input type="file" accept="image/*" hidden data-k="bp"></label><label class="upl" id="ls"><span>صورة المحل</span><input type="file" accept="image/*" hidden data-k="sp"></label>' : '') +
      '<button class="btn" id="go">' + (reg ? 'إرسال طلب الانضمام' : 'دخول') + '</button></div>';
    V.installHint(root);
    root.querySelectorAll('.seg button').forEach(function (b) { b.onclick = function () { S.reg = b.dataset.r === '1'; viewAuth(); }; });
    root.querySelectorAll('input[type=file]').forEach(function (inp) {
      inp.onchange = async function () {
        var f = inp.files[0]; if (!f) return;
        try {
          var blob = await V.resizeImage(f, 1000); S.photos[inp.dataset.k] = blob;
          var lab = inp.closest('label'); lab.innerHTML = '<img src="' + URL.createObjectURL(blob) + '" alt=""><span>تم اختيار الصورة</span>';
        } catch (e) { V.toast(V.errText(e)); }
      };
    });
    V.$('#go').onclick = doAuth;
  }
  async function doAuth() {
    var ph = V.$('#ph').value, pw = V.$('#pw').value, btn = V.$('#go'), digits = ph.replace(/\D/g, '');
    if (digits.length < 9 || pw.length < 6) { V.toast('أدخل رقم هاتف صحيح وكلمة سر من 6 أحرف على الأقل'); return; }
    var n, sh, ad;
    if (S.reg) { n = V.$('#n').value.trim(); sh = V.$('#sh').value.trim(); ad = V.$('#ad').value.trim(); if (!n || !sh || !ad) { V.toast('أكمل اسم الحلاق واسم المحل والعنوان'); return; } }
    btn.disabled = true; var old = btn.textContent; btn.textContent = '...';
    try {
      var email = emailOf(ph);
      if (S.reg) {
        var r = await sb.auth.signUp({ email: email, password: pw });
        if (r.error) {
          var m = (r.error.message || '').toLowerCase();
          if (m.indexOf('already') >= 0 || m.indexOf('registered') >= 0) { var r2 = await sb.auth.signInWithPassword({ email: email, password: pw }); if (r2.error) throw r2.error; }
          else throw r.error;
        } else if (!r.data.session) throw new Error('فعّل تسجيل الدخول بدون تأكيد البريد في إعدادات Supabase');
        var bu = null, su = null;
        if (S.photos.bp) bu = await V.uploadPhoto(S.photos.bp, 'barber');
        if (S.photos.sp) su = await V.uploadPhoto(S.photos.sp, 'shop');
        var rr = await sb.rpc('vp_register_barber', { p_name: n, p_shop: sh, p_phone: ph.trim(), p_address: ad, p_bphoto: bu, p_sphoto: su });
        if (rr.error) throw rr.error;
      } else {
        var r3 = await sb.auth.signInWithPassword({ email: email, password: pw }); if (r3.error) throw r3.error;
      }
      await boot();
    } catch (e) { V.toast(V.errText(e)); btn.disabled = false; btn.textContent = old; }
  }
  async function logout() {
    [chBook, chBarb].forEach(function (c) { if (c) sb.removeChannel(c); }); chBook = chBarb = null; clearInterval(pollT);
    await sb.auth.signOut(); S.b = null; S.photos = {}; S.known = {}; S.first = true; viewAuth();
  }

  /* ---------- الحالة (انتظار موافقة المالك...) ---------- */
  function viewStatus() {
    var st = S.b.status;
    var msg = st === 'pending' ? 'طلبك وصل إلى المالك. ستظهر للزبائن فور موافقته، وستتغير هذه الشاشة تلقائيًا.'
      : st === 'rejected' ? 'تم رفض طلب انضمامك. تواصل مع المالك لمعرفة السبب.' : 'حسابك موقوف حاليًا. تواصل مع المالك لإعادة التفعيل.';
    root.innerHTML = '<div class="login"><img class="logo" src="../shared/icons/logo.png" alt=""><div style="margin:18px 0">' + V.chip(st) + '</div><p style="line-height:1.8;font-size:16px;margin-bottom:24px">' + msg + '</p>' +
      '<button class="btn ghost" id="lo">تسجيل الخروج</button></div>';
    V.$('#lo').onclick = logout;
  }
  async function refreshBarber() {
    var r = await sb.from('vp_barbers').select('*').eq('user_id', uid).maybeSingle();
    if (r.error || !r.data) return;
    var was = S.b && S.b.status; S.b = r.data;
    if (S.b.status !== 'approved') viewStatus();
    else if (was !== 'approved') { startApproved(); }
  }

  /* ---------- التطبيق الرئيسي ---------- */
  function shell(inner) {
    root.innerHTML =
      '<div class="top"><div class="brand"><img src="../shared/icons/logo.png" alt=""><div><b>BARBER VIPROMAX</b><small>' + esc(S.b.shop_name) + '</small></div></div></div>' +
      '<main id="main">' + inner + '</main>' +
      '<nav><button data-tab="0" class="' + (S.tab === 0 ? 'on' : '') + '">الطلبات</button><button data-tab="1" class="' + (S.tab === 1 ? 'on' : '') + '">الأرباح</button><button data-tab="2" class="' + (S.tab === 2 ? 'on' : '') + '">ملفي</button></nav>';
    root.querySelectorAll('nav button').forEach(function (b) { b.onclick = function () { S.tab = +b.dataset.tab; render(); }; });
  }
  function render() {
    shell('<div class="spin"><img src="../shared/icons/logo.png" alt=""></div>');
    if (S.tab === 0) { paintRequests(); loadBookings(true); }
    else if (S.tab === 1) viewFinance(); else viewProfile();
  }
  async function loadBookings(silent) {
    var r = await sb.from('vp_bookings').select('*').eq('barber_id', S.b.id).order('scheduled_at', { ascending: true });
    if (r.error) { if (!silent) V.toast(V.errText(r.error)); return; }
    S.bookings = r.data || [];
    S.bookings.forEach(function (k) {
      if (!S.first && !S.known[k.id] && k.status === 'pending' && k.source === 'app') { V.toast('طلب حجز جديد من ' + k.customer_name); if (navigator.vibrate) navigator.vibrate([150, 80, 150]); }
      S.known[k.id] = true;
    });
    S.first = false; if (S.tab === 0 && !document.querySelector('.mbg')) paintRequests();
  }
  function paintRequests() {
    var m = V.$('#main'); if (!m) return; var b = S.b;
    var h = '<h1>أهلًا ' + esc(String(b.barber_name).split(' ')[0]) + '</h1>' +
      '<div class="card row"><div class="grow"><div class="nm">' + (b.is_available ? 'أنت متاح للحجز' : 'أنت مغلق') + '</div><div class="mt">' + (b.is_available ? 'تظهر للزبائن' : 'لا تظهر للزبائن') + '</div></div><button class="tg ' + (b.is_available ? 'on' : '') + '" id="tg" aria-label="التوفر"></button></div>' +
      '<button class="btn ghost" id="walk">تسجيل زبون بدون حجز</button><h2>الطلبات</h2>';
    var l = S.bookings.filter(function (k) { return k.status === 'pending' || k.status === 'accepted'; });
    if (!l.length) h += '<div class="empty">لا توجد طلبات حاليًا</div>';
    l.forEach(function (k) {
      h += '<div class="card"><div class="row">' + V.avatar(k.customer_photo_url, V.initial(k.customer_name), 48) +
        '<div class="grow"><div class="nm" style="font-size:16px">' + esc(k.customer_name) + '</div><div class="mt ltr" style="text-align:right">' + (k.source === 'walkin' ? 'بدون حجز' : V.fmtDt(k.scheduled_at)) + '</div></div>' + V.chip(k.status) + '</div>' +
        (k.customer_phone ? '<a class="mt ltr" style="display:block;color:var(--gd2);text-align:right;margin-top:6px;text-decoration:none" href="tel:' + esc(String(k.customer_phone).replace(/\s/g, '')) + '">📞 ' + esc(k.customer_phone) + '</a>' : '') +
        '<div class="acts">' + (k.status === 'pending'
          ? '<button class="btn sm" data-acc="' + k.id + '">قبول</button><button class="btn sm red" data-rej="' + k.id + '">رفض</button>'
          : '<button class="btn sm" data-done="' + k.id + '">إتمام الخدمة</button>') + '</div></div>';
    });
    m.innerHTML = h;
    V.$('#tg').onclick = toggleAvail; V.$('#walk').onclick = walkin;
    m.querySelectorAll('[data-acc]').forEach(function (x) { x.onclick = function () { act('vp_respond_booking', { p_booking: x.dataset.acc, p_accept: true }, 'تم قبول الحجز', x); }; });
    m.querySelectorAll('[data-rej]').forEach(function (x) { x.onclick = function () { act('vp_respond_booking', { p_booking: x.dataset.rej, p_accept: false }, 'تم رفض الحجز', x); }; });
    m.querySelectorAll('[data-done]').forEach(function (x) { x.onclick = function () { act('vp_complete_booking', { p_booking: x.dataset.done }, 'اكتملت الخدمة: 1,000 دج لك', x); }; });
  }
  async function act(fn, params, ok, btn) {
    if (btn) btn.disabled = true;
    var r = await sb.rpc(fn, params);
    if (r.error) { V.toast(V.errText(r.error)); if (btn) btn.disabled = false; return; }
    V.toast(ok); loadBookings(true);
  }
  async function toggleAvail() {
    var v = !S.b.is_available, r = await sb.from('vp_barbers').update({ is_available: v }).eq('id', S.b.id);
    if (r.error) { V.toast(V.errText(r.error)); return; } S.b.is_available = v; paintRequests();
  }
  function walkin() {
    var m = V.modal('<div class="pad"><div class="nm">زبون بدون حجز</div><p class="sub">اسم الزبون (اختياري)</p><input id="wn" class="inp" placeholder="الاسم"><div class="acts"><button class="btn sm" id="wo">تسجيل</button><button class="btn sm ghost" data-close>إلغاء</button></div></div>', { center: true });
    m.$('#wo').onclick = async function () {
      var r = await sb.rpc('vp_create_walkin', { p_name: m.$('#wn').value }); if (r.error) { V.toast(V.errText(r.error)); return; }
      m.close(); V.toast('تم تسجيل الزبون'); loadBookings(true);
    };
  }
  async function viewFinance() {
    var f = await sb.from('vp_finance').select('*').eq('barber_id', S.b.id).maybeSingle();
    var c = await sb.from('vp_completions').select('*').eq('barber_id', S.b.id).order('completed_at', { ascending: false }).limit(30);
    var d = f.data || {}, n = function (k) { return Number(d[k] || 0); }, rows = c.data || [];
    var h = '<h1>الأرباح</h1><p class="sub">صافي مستحقاتك</p><div class="big">' + V.money(n('barber_total')) + '</div><div class="mt" style="margin-bottom:18px">من ' + n('services') + ' خدمة مكتملة</div>' +
      '<div class="card"><div class="line"><span>قيمة الخدمات الإجمالية</span><b>' + V.money(n('gross')) + '</b></div><div class="line"><span>مجموع خصومات المنصة</span><b>' + V.money(n('platform_total')) + '</b></div><div class="line"><span>ما دفعته للمالك</span><b>' + V.money(n('paid_to_owner')) + '</b></div><div class="line"><span>المتبقي عليك للمالك</span><b style="color:var(--gd2)">' + V.money(n('remaining')) + '</b></div></div>' +
      '<div class="card"><div class="line"><span>سعر الخدمة</span><b>1,500 دج</b></div><div class="line"><span>خصم المنصة</span><b>− 500 دج</b></div><div class="line"><span>لك</span><b style="color:var(--ok)">1,000 دج</b></div></div><h2>آخر الخدمات</h2>';
    if (!rows.length) h += '<div class="empty">لا توجد خدمات بعد</div>';
    rows.forEach(function (r) { h += '<div class="line"><span class="ltr">' + V.fmtDt(r.completed_at) + '</span><b style="color:var(--ok)">+ ' + V.money(r.barber_net) + '</b></div>'; });
    var m = V.$('#main'); if (m && S.tab === 1) m.innerHTML = h;
  }
  function viewProfile() {
    var b = S.b;
    V.$('#main').innerHTML = '<div style="position:relative;margin-bottom:46px">' + V.shopImg(b.shop_photo_url, 170).replace('class="shop"', 'class="shop" style="border-radius:20px;') + '<div style="position:absolute;inset-inline-end:16px;bottom:-34px">' + V.avatar(b.barber_photo_url, V.initial(b.barber_name), 78) + '</div></div>' +
      '<div class="card"><div class="nm" style="font-size:20px">' + esc(b.shop_name) + '</div><div class="line" style="margin-top:8px"><span>الحلاق</span><b>' + esc(b.barber_name) + '</b></div><div class="line"><span>الهاتف</span><b class="ltr">' + esc(b.phone) + '</b></div><div class="line"><span>العنوان</span><b>' + esc(b.address) + '</b></div></div>' +
      '<button class="btn ghost" id="lo">تسجيل الخروج</button>';
    V.$('#lo').onclick = logout;
  }
  function startApproved() {
    clearInterval(pollT); pollT = setInterval(function () { if (document.visibilityState === 'visible') { if (S.tab === 0) loadBookings(true); } }, 15000);
    if (chBook) sb.removeChannel(chBook);
    chBook = sb.channel('vp-b-' + S.b.id).on('postgres_changes', { event: '*', schema: 'public', table: 'vp_bookings', filter: 'barber_id=eq.' + S.b.id }, function () { loadBookings(true); }).subscribe();
    S.first = true; render();
  }

  /* ---------- الإقلاع ---------- */
  async function boot() {
    var s = (await sb.auth.getSession()).data.session;
    if (!s) { viewAuth(); return; }
    uid = s.user.id;
    var r = await sb.from('vp_barbers').select('*').eq('user_id', uid).maybeSingle();
    if (!r.data) { viewAuth(); return; }
    S.b = r.data;
    if (chBarb) sb.removeChannel(chBarb);
    chBarb = sb.channel('vp-bb-' + uid).on('postgres_changes', { event: '*', schema: 'public', table: 'vp_barbers', filter: 'user_id=eq.' + uid }, refreshBarber).subscribe();
    if (S.b.status === 'approved') startApproved();
    else { viewStatus(); clearInterval(pollT); pollT = setInterval(function () { if (document.visibilityState === 'visible') refreshBarber(); }, 10000); }
  }
  boot().catch(function (e) { root.innerHTML = '<div class="empty">' + esc(V.errText(e)) + '<br><br><button class="btn" onclick="location.reload()">إعادة المحاولة</button></div>'; });
})();
